<?php

namespace App\Repositories\Exceptions;

/**
 * Class RepositoryException
 * @package Bosnadev\Repositories\Exceptions
 */
class RepositoryException extends \Exception
{

}
